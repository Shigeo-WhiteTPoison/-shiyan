package com.example.culator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText txt_result;
    Button btn_1,btn_2,btn_3,btn_4,btn_5,btn_6,btn_7,btn_8,btn_9,btn_0,btn_qing,btn_jia,btn_jian,btn_cheng,btn_chu,btn_deng;
    double num1,num2,ans=99999999;
    boolean isclicked;
    String unnum="%";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        btn_1=(Button)findViewById(R.id.btn_1);
        btn_0=(Button)findViewById(R.id.btn_0);
        btn_2=(Button)findViewById(R.id.btn_2);
        btn_3=(Button)findViewById(R.id.btn_3);
        btn_4=(Button)findViewById(R.id.btn_4);
        btn_5=(Button)findViewById(R.id.btn_5);
        btn_6=(Button)findViewById(R.id.btn_6);
        btn_7=(Button)findViewById(R.id.btn_7);
        btn_8=(Button)findViewById(R.id.btn_8);
        btn_9=(Button)findViewById(R.id.btn_9);
        btn_qing=(Button)findViewById(R.id.btn_qing);
        btn_deng=(Button)findViewById(R.id.btn_deng);
        btn_jia=(Button)findViewById(R.id.btn_jia);
        btn_jian=(Button)findViewById(R.id.btn_jian);
        btn_cheng=(Button)findViewById(R.id.btn_cheng);
        btn_chu=(Button)findViewById(R.id.btn_chu);
        txt_result=(EditText)findViewById(R.id.txt_result);


        btn_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }

                txt_result.setText(txt_result.getText().toString()+"0");
            }
        });
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"1");
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"2");
            }
        });
        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"3");
            }
        });
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"4");
            }
        });
        btn_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"5");
            }
        });
        btn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"6");
            }
        });
        btn_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"7");
            }
        });
        btn_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"8");
            }
        });
        btn_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText(txt_result.getText().toString()+"9");
            }
        });
        btn_qing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isclicked){
                    txt_result.setText("");
                    isclicked=false;
                }
                txt_result.setText("");
            }
        });
        btn_cheng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txt_result.equals(null)){return;}
                String st=txt_result.getText().toString();
                num1=Double.valueOf(st);
            }
        });
        btn_chu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txt_result.equals(null)){return;}
                String st=txt_result.getText().toString();
                num1=Double.valueOf(st);
            }
        });
        btn_jia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {if(txt_result.equals(null)){return;}
                String st=txt_result.getText().toString();
                num1=Double.valueOf(st);
            }
        });
        btn_jian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {if(txt_result.equals(null)){return;}
                String st=txt_result.getText().toString();
                num1=Double.valueOf(st);
            }
        });
        btn_deng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isclicked=true;
                txt_result.setText(Double.toString(ans));

            }
        });





        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


}
