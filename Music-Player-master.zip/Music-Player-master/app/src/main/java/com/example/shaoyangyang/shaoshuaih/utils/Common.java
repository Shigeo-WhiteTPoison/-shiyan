package com.example.shaoyangyang.shaoshuaih.utils;

import com.example.shaoyangyang.shaoshuaih.entity.Music;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shaoyangyang on 2017/12/20.
 */

public class Common {

    public static List<Music> musicList = new ArrayList<>();
}
