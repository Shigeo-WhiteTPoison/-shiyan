package com.example.shiyan11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private  final  String Tag="MainActivity";
    private TextView tv_input;
    private  float result;
    private String fuhao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUi();
    }
    private void initUi() {
        tv_input = findViewById(R.id.tv_input);
    }
    private String getresult() {
        String data= tv_input.getText().toString();
        //将数字与运算符号切割
        String[] str1 = data.split(" ");
        //循环计算，得到最后结果
        while (str1.length!=1){
            //×,÷计算方法
            for(int i=0;i<str1.length;i++){
                if(str1[i].equals("×")||str1[i].equals("÷")){
                    if(str1[i].equals("×")){
                            str1[i]=(Float.parseFloat(str1[i-1])*Float.parseFloat(str1[i+1]))+"";
                            int [] index=new int[]{i-1,i+1};
                            str1=deletestr(index,str1);

                    }

                    else{
                        str1[i]=(Float.parseFloat(str1[i-1])/Float.parseFloat(str1[i+1]))+"";
                        int [] index=new int[]{i-1,i+1};
                        str1=deletestr(index,str1);
                    }
                }
            }
            //+,-计算方法
            for(int i=0;i<str1.length;i++){
                if("+".equals(str1[i])||"-".equals(str1[i])){
                    if(str1[i].equals("+")){
                        str1[i]=(Float.parseFloat(str1[i-1])+Float.parseFloat(str1[i+1]))+"";
                        int [] index=new int[]{i-1,i+1};
                        str1=deletestr(index,str1);
                    }else {
                        str1[i]=(Float.parseFloat(str1[i-1])-Float.parseFloat(str1[i+1]))+"";
                        int [] index=new int[]{i-1,i+1};
                        str1=deletestr(index,str1);
                    }
                }
            }
            for(int i=0;i<str1.length;i++){
                if("½".equals(str1[i])){
                    if(str1[i].equals("½")){
                        str1[i]=(java.lang.Math.sqrt((double)Float.parseFloat(str1[i-1])))+"";
                        int [] index=new int[]{i-1,i+1};
                        str1=deletestr(index,str1);
                    }else {
                        str1[i]=(Float.parseFloat(str1[i-1])*Float.parseFloat(str1[i+1]))+"";
                        int [] index=new int[]{i-1,i+1};
                        str1=deletestr(index,str1);
                    }
                }
            }

        }
        return str1[0];
    }
    //同时删除数组中计算完成符号左右数
    private String[] deletestr(int [] i, String[] str1) {
        List<String> strs=new ArrayList<String>();
        for(String s:str1){
            strs.add(s);
        }
        strs.remove(i[0]);
        strs.remove(i[1]-1);
        String str[]=new   String[str1.length-2];
        for(int j = 0;j<str.length;j++){
            str[j]=strs.get(j);
        }
        return  str;
    }

    private void tvInputtext(String s) {
        //第一次输入 将0去除，以及上次结果置空
        if(tv_input.getText().toString().equals("0")||tv_input.getText().toString().contains("=")){
            tv_input.setText("");
        }
        //符号左右添加空格方便split
        if(s.equals("×")||s.equals("-")||s.equals("+")||s.equals("÷")||s.equals("￥")||s.equals("½")||s.equals("^2")){
            tv_input.setText(tv_input.getText()+" "+s+" ");
        }else {
            tv_input.setText(tv_input.getText()+s);
        }
    }
    //按钮点击事件
    public  void onSubmit(View view){
        int id = view.getId();
        switch (id){
            case R.id.bt_value0:
                tvInputtext("0");
                break;
            case R.id.bt_value1:
                tvInputtext("1");
                break;
            case R.id.bt_value2:
                tvInputtext("2");
                break;
            case R.id.bt_value3:
                tvInputtext("3");
                break;
            case R.id.bt_value4:
                tvInputtext("4");
                break;
            case R.id.bt_value5:
                tvInputtext("5");
                break;
            case R.id.bt_value6:
                tvInputtext("6");
                break;
            case R.id.bt_value7:
                tvInputtext("7");
                break;
            case R.id.bt_value8:
                tvInputtext("8");
                break;
            case R.id.bt_value9:
                tvInputtext("9");
                break;
            case R.id.bt_cheng:
                tvInputtext("×");
                break;
            case R.id.bt_chu:
                tvInputtext("÷");
                break;
            case R.id.bt_clean:
                //清除按钮 置空
                tv_input.setText("");
                break;
            case R.id.bt_dengyu:
                tv_input.setText(tv_input.getText()+"="+getresult());
                break;
            case R.id.bt_dian:
                tvInputtext(".");
                break;
            case R.id.bt_jia:
                tvInputtext("+");
                break;
            case R.id.bt_jian:
                tvInputtext("-");
                break;
            case R.id.bt_dao:
                tv_input.setText("1"+" ÷ "+tv_input.getText());
                break;
            case R.id.bt_gen:
                tv_input.setText(tv_input.getText()+" ½ 次");
                break;
            case R.id.bt_ping:
                tv_input.setText(tv_input.getText()+" × "+tv_input.getText());
                break;
        }
    }
}